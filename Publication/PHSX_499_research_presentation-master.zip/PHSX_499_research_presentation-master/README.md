# PHSX_499_research_presentation
Latex slideshow presenting research undertaken in MOSES lab, lead by Charles Kankelborg. Will present to PHSX499 class for senior project.
